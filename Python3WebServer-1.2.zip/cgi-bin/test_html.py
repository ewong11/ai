#! /usr/bin/env python3

HTML_HEADER='Content-type: text/html\n\n'

def Main():
    print (HTML_HEADER+'<html><body>')
    print ('<b> Success. Python is able to generate HTML text from the <i>cgi-bin/python-stuff</i> directory.</b><p>')
    print ('(Now hit the BACK button)</body></html>')

Main()
